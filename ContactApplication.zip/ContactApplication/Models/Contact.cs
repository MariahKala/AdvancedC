﻿using System.ComponentModel.DataAnnotations;

namespace ContactApplication.Models
{
    public class Contact
    {
        //Values Name, Phone Number, Address and Note
        // EF Core will configure the database to generate this value

        public int ContactId { get; set; }

        [Required(ErrorMessage = "Please enter a name.")]
        public string Name { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please enter a phone number.")]

        public long? PhoneNumber { get; set; }

        [Required(ErrorMessage = "Please enter an address.")]

        public string? Address { get; set; }

        [Required(ErrorMessage = "Please enter a note.")]

        public string? Note { get; set; }

        //Slug File learning how to do for my class
        //public string Slug =>
   //Name?.Replace(' ', '-').ToLower() + '-' +
       //PhoneNumber?.ToString();
    }
}
