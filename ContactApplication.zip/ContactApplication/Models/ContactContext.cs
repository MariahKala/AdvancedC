﻿using Microsoft.EntityFrameworkCore;


namespace ContactApplication.Models
{
    public class ContactContext : DbContext
    {
        public ContactContext(DbContextOptions<ContactContext> options)
            : base(options)
        { }
        public DbSet<Contact> Contacts { get; set; } = null!;
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Contact>().HasData(
                new Contact
                {
                    ContactId = 1,
                    Name = "Mariah Kennedy",
                    PhoneNumber = 6666666666,
                    Address = "West Elm, Tustin California",
                    Note = "My old address"
                },

                new Contact
                {
                    ContactId = 2,
                    Name = "Jordan Hildreth",
                    PhoneNumber = 5153234567,
                    Address = "Blue True, Orange Florida",
                    Note = "Huny"
                },
                new Contact
                {
                    ContactId = 3,
                    Name = "Lucky Stripes",
                    PhoneNumber = 6267778890,
                    Address = "454 8th ave, Dayton Wisconson.",
                    Note = "Cigs"
                }
        );

        }

    }
}
