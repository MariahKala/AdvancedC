﻿using Microsoft.AspNetCore.Mvc;
using AgeApp.Models;

namespace AgeApp.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            ViewBag.FV = 0;
            return View();
        }
        [HttpPost]
        public IActionResult Index(AgeCalc model)
        {
            if (ModelState.IsValid)
            {
                ViewBag.FV = model.AgeThisYear();
            }
            else
            {
                ViewBag.FV = 0;
            }
            return View(model);
        }
    }
}
