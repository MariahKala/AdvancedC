﻿using System.ComponentModel.DataAnnotations;

namespace AgeApp.Models
{
    public class AgeCalc
    {
        //Setting name variable with getters and seters.
        [Required(ErrorMessage =
        "Please enter valid name")]
        public string? Name { get; set; }

        //Setting birth year variable with getters and setters.
        [Required(ErrorMessage =
        "Please enter a birth year.")]
        [Range(1900, 2023, ErrorMessage =
        "Please enter a valid year between the year 1900 and 2023.")]
        public int? birthYear { get; set; }

        public int? AgeThisYear()
        {
            int? currentYear = DateTime.Now.Year;
            int? age = 0;
            age = currentYear - birthYear;
            return age;
        }
    }
}
